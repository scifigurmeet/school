<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class globalOptionsModel extends Model
{
    protected $table = 'global_options';
}
